﻿# AffectGPT — Emotion-Aware Python Chatbot (PAD + Mood)
Run:
1) python -m venv .venv
2) .\.venv\Scripts\Activate
3) pip install -r requirements.txt
4) streamlit run ui\app.py
