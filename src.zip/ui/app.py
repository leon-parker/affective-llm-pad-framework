﻿# ui/app.py — Streamlit 1.39, PAD + Persona sliders + LLM
import os, sys
import streamlit as st
import plotly.graph_objects as go

# Make ./src importable
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)

from affectgpt.emotion import Mood, PAD
from affectgpt.appraisal import analyze
from affectgpt.style import style_from_pad
from affectgpt.policy import render_response
from affectgpt.safety import check as safety_check

st.set_page_config(page_title="AffectGPT", page_icon="💬", layout="centered")
st.title("AffectGPT — Emotion-Aware Chatbot (PAD)")
st.caption("Mood-aware, explainable, and supportive.")

# ── Session state ──────────────────────────────────────────────────────────────
if "mood" not in st.session_state:
    st.session_state.mood = Mood(decay=0.85)
if "history" not in st.session_state:
    # store (user_text, bot_text, emotion_label)
    st.session_state.history = []

# ── Sidebar: strategy + persona controls ───────────────────────────────────────
strategy = st.sidebar.selectbox("Emotional strategy", ["mirror", "regulate"], index=1)

st.sidebar.markdown("### Persona (PAD bias)")
val_bias = st.sidebar.slider("Valence bias (optimism)",  -0.5, 0.5, 0.0, 0.05)
aro_bias = st.sidebar.slider("Arousal bias (energy)",    -0.5, 0.5, 0.0, 0.05)
dom_bias = st.sidebar.slider("Dominance bias (confidence)", -0.5, 0.5, 0.0, 0.05)
persona_weight = st.sidebar.slider("Persona weight", 0.0, 1.0, 0.5, 0.05,
                                   help="How strongly the persona biases mood & style")

st.sidebar.markdown("### Communication style overrides")
ov_formality  = st.sidebar.slider("Formality", 0.0, 1.0, 0.5, 0.05)
ov_directness = st.sidebar.slider("Directness (↔ hedging)", 0.0, 1.0, 0.5, 0.05)
ov_emoji      = st.sidebar.slider("Emoji / playfulness", 0.0, 1.0, 0.5, 0.05)

cols = st.sidebar.columns(2)
if cols[0].button("Reset mood", use_container_width=True):
    st.session_state.mood = Mood(decay=0.85)
    st.rerun()
if cols[1].button("Clear chat", use_container_width=True):
    st.session_state.history = []
    st.rerun()

# Current PAD (true mood, no bias applied yet)
pad_true = st.session_state.mood.current()

# Apply persona PAD bias with blend
biased_pad = PAD(
    pad_true.pleasure + val_bias * persona_weight,
    pad_true.arousal  + aro_bias * persona_weight,
    pad_true.dominance+ dom_bias * persona_weight,
).clipped()

# Read-only sliders show the *biased* PAD (what the bot "acts" like)
st.sidebar.markdown("### Mood (PAD)")
st.sidebar.slider("Pleasure (valence)", -1.0, 1.0, float(biased_pad.pleasure), 0.01, disabled=True)
st.sidebar.slider("Arousal",            -1.0, 1.0, float(biased_pad.arousal),  0.01, disabled=True)
st.sidebar.slider("Dominance",          -1.0, 1.0, float(biased_pad.dominance),0.01, disabled=True)

# Mood history chart (of true mood over turns)
hist = [p.as_tuple() for p in st.session_state.mood.history]
if hist:
    x = list(range(len(hist)))
    v = [h[0] for h in hist]; a = [h[1] for h in hist]; d = [h[2] for h in hist]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=v, name="Pleasure"))
    fig.add_trace(go.Scatter(x=x, y=a, name="Arousal"))
    fig.add_trace(go.Scatter(x=x, y=d, name="Dominance"))
    fig.update_layout(height=250, margin=dict(l=10, r=10, t=10, b=10))
    st.sidebar.plotly_chart(fig, use_container_width=True)

st.divider()

# ── Chat input (form = Enter to submit) ───────────────────────────────────────
with st.form(key="chat_form"):
    user_text = st.text_input("You:", placeholder="Tell me what's going on…", key="chat_input")
    submitted = st.form_submit_button("Send", use_container_width=True)

if submitted and user_text.strip():
    # Safety first
    crisis = safety_check(user_text)
    if crisis:
        st.session_state.history.append((user_text, crisis, "safety"))
        st.rerun()

    # Appraise → PAD delta → update TRUE mood (no persona bias here)
    label, delta, signals = analyze(user_text)
    new_pad_true = st.session_state.mood.update(delta)

    # Style derived from *biased* PAD; then apply user overrides
    style = style_from_pad(biased_pad)
    style.formality = ov_formality
    style.hedging   = 1.0 - ov_directness   # more direct → less hedging
    style.emoji     = ov_emoji
    # lightly tie pace to both computed pace and arousal bias
    style.pace      = max(0.0, min(1.0, 0.5 * style.pace + 0.5 * (0.5 + aro_bias)))

    persona = {
        "valence_bias": val_bias,
        "arousal_bias": aro_bias,
        "dominance_bias": dom_bias,
        "weight": persona_weight,
        "formality": ov_formality,
        "directness": ov_directness,
        "emoji": ov_emoji,
    }

    # Generate response using *biased* PAD + persona-aware style
    bot = render_response(user_text, biased_pad, style, strategy=strategy, persona=persona)

    st.session_state.history.append((user_text, bot, label))
    st.rerun()

# ── Chat display ──────────────────────────────────────────────────────────────
for u, b, lbl in st.session_state.history[-12:]:
    with st.chat_message("user"):
        st.write(u)
    with st.chat_message("assistant"):
        st.markdown(f"**[{lbl}]** {b}")

# ── Explainability ────────────────────────────────────────────────────────────
with st.expander("Why this reply? (explainability)"):
    last = st.session_state.mood.current()
    st.write(
        f"True PAD: pleasure={last.pleasure:.2f}, arousal={last.arousal:.2f}, dominance={last.dominance:.2f}  \n"
        f"Biased PAD: pleasure={biased_pad.pleasure:.2f}, arousal={biased_pad.arousal:.2f}, dominance={biased_pad.dominance:.2f}"
    )
    st.markdown(
        "- Signals: VADER + keyword rules.\n"
        "- Mood: exponential decay (prevents whiplash).\n"
        "- Persona: PAD bias + style overrides (formality/directness/emoji).\n"
        "- Strategy: mirror vs regulate (nudges arousal toward calm when regulating)."
    )
