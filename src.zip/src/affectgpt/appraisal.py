﻿import re
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from .emotion import PAD
_v = SentimentIntensityAnalyzer()

EMOTION_TO_PAD = {
  'joy': PAD(+0.8,+0.2,+0.2),
  'gratitude': PAD(+0.6,+0.1,+0.2),
  'anger': PAD(-0.7,+0.6,+0.4),
  'sadness': PAD(-0.7,-0.4,-0.4),
  'fear': PAD(-0.8,+0.5,-0.6),
  'neutral': PAD(0,0,0),
}
RULES = [
  (re.compile(r'\b(thanks|appreciate|grateful)\b', re.I),'gratitude'),
  (re.compile(r'\b(angry|furious|pissed)\b', re.I),'anger'),
  (re.compile(r'\b(sad|upset|depressed)\b', re.I),'sadness'),
  (re.compile(r'\b(scared|afraid|panic|anxious)\b', re.I),'fear'),
  (re.compile(r'\b(happy|great|awesome|love it)\b', re.I),'joy'),
]

def analyze(text: str):
  t = text.strip()
  for rx,label in RULES:
    if rx.search(t):
      return label, EMOTION_TO_PAD[label], {'kw:'+label:1.0}
  s = _v.polarity_scores(t)
  comp = s.get('compound',0.0)
  if comp >= 0.4:  return 'joy', EMOTION_TO_PAD['joy'], s
  if comp <= -0.4:
    if re.search(r'!|[A-Z]{2,}', t): return 'anger', EMOTION_TO_PAD['anger'], s
    return 'sadness', EMOTION_TO_PAD['sadness'], s
  return 'neutral', EMOTION_TO_PAD['neutral'], s
