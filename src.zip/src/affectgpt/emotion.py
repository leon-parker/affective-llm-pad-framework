﻿from dataclasses import dataclass
from typing import Tuple, List, Optional

@dataclass
class PAD:
    """Represents the Pleasure–Arousal–Dominance (PAD) affective state."""
    pleasure: float
    arousal: float
    dominance: float

    def clipped(self) -> "PAD":
        """Clip PAD values to [-1, +1] to prevent overflow."""
        return PAD(
            max(-1, min(1, self.pleasure)),
            max(-1, min(1, self.arousal)),
            max(-1, min(1, self.dominance))
        )

    def as_tuple(self) -> Tuple[float, float, float]:
        """Return (pleasure, arousal, dominance) as a tuple."""
        return (self.pleasure, self.arousal, self.dominance)

    @staticmethod
    def zero() -> "PAD":
        """Return a neutral (0,0,0) PAD state."""
        return PAD(0.0, 0.0, 0.0)

    def scale(self, factor: float) -> "PAD":
        """Scale all PAD dimensions by a factor."""
        return PAD(
            self.pleasure * factor,
            self.arousal * factor,
            self.dominance * factor
        )


class Mood:
    """Maintains a decaying emotional mood state in PAD space."""

    def __init__(self, decay: float = 0.85, baseline: Optional[PAD] = None):
        """
        Args:
            decay: how quickly past emotions fade (0.8 = slow, 0.95 = very persistent)
            baseline: starting PAD state (defaults to neutral)
        """
        self.decay = decay
        self.state = baseline if baseline else PAD.zero()
        self.history: List[PAD] = [self.state]

    def update(self, delta: PAD, blend: float = 0.25) -> PAD:
        """Update the mood based on a new PAD delta and store history."""
        decayed = self.state.scale(self.decay)
        self.state = PAD(
            decayed.pleasure + delta.pleasure * blend,
            decayed.arousal + delta.arousal * blend,
            decayed.dominance + delta.dominance * blend
        ).clipped()
        self.history.append(self.state)
        return self.state

    def current(self) -> PAD:
        """Return the current PAD mood state."""
        return self.state

    def reset(self, baseline: Optional[PAD] = None):
        """Reset mood back to neutral or to a custom baseline."""
        self.state = baseline if baseline else PAD.zero()
        self.history = [self.state]
